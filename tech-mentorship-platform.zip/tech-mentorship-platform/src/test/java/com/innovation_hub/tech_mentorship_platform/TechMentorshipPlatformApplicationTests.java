package com.innovation_hub.tech_mentorship_platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechMentorshipPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
