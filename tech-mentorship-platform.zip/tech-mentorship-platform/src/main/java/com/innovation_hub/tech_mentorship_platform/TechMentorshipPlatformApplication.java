package com.innovation_hub.tech_mentorship_platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechMentorshipPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechMentorshipPlatformApplication.class, args);
	}

}
